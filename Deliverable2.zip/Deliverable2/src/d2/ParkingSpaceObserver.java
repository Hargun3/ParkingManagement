package d2;

public interface ParkingSpaceObserver {
    void updateVacancy();
}
