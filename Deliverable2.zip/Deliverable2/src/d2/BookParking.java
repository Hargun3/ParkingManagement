package d2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;

public class BookParking implements Command {
    private Booking booking;
    private ParkingSpace space;

    public BookParking(Booking booking, ParkingSpace space) {
        this.booking = booking;
        this.space = space;
    }

    @Override
    public boolean execute() throws IOException {
        CsvWriter output = null;
        try {
            output = new CsvWriter(new FileWriter("Deliverable2/booking.csv", true), ',');
            output.write(String.valueOf(booking.id));
            output.write(booking.startTime.toString());
            output.write(space.getspace_Location());
            output.endRecord();
        } finally {
            if (output != null) {
                output.close();
            }
        }
        return true;
    }
    
    

    @Override
    public boolean undo() throws IOException {
        CsvReader reader = new CsvReader("Deliverable2/booking.csv");
        ArrayList<String[]> list = new ArrayList<>();

        while (reader.readRecord()) {
            if (!reader.get("id").equals(String.valueOf(booking.id))) {
                list.add(new String[]{reader.get("id"), reader.get("start_time"), reader.get("space")});
            }
        }
        reader.close();

        CsvWriter output = null;
        try {
            output = new CsvWriter(new FileWriter("Deliverable2/booking.csv", false), ',');
            for (String[] entry : list) {
                output.write(entry[0]);
                output.write(entry[1]);
                output.write(entry[2]);
                output.endRecord();
            }
        } finally {
            if (output != null) {
                output.close();
            }
        }

        return true;
    }
}
