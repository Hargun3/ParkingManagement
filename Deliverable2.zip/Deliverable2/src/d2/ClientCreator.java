package d2;

public interface ClientCreator {
	
	public Client createClient();
	
}
