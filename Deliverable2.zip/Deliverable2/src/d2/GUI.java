package d2;

import javax.swing.*;

import com.csvreader.CsvReader;

import java.awt.*;
import java.io.IOException;
import java.util.Date;

public class GUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JLabel dashboardLabel;

    private Client currentUser;

    public GUI() {
        setTitle("Parking Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPanel(), "login");
        mainPanel.add(createRegisterPanel(), "register");
        mainPanel.add(createBookingPanel(), "booking");

        add(mainPanel);
        cardLayout.show(mainPanel, "login");
    }

    private boolean isManager(String email) {
        for (Manager manager : SuperManager.getInstance().accessAccountGenerator(AccountGenerator.getInstance())) {
            if (manager.getUsername().equals(email)) {
                return true;
            }
        }
        return false;
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Login", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField emailField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JButton loginBtn = new JButton("Login");
        JButton toRegisterBtn = new JButton("Register");

        JPanel inputPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        inputPanel.add(emailField);
        inputPanel.add(passwordField);

        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        toRegisterBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(inputPanel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(loginBtn);
        panel.add(Box.createVerticalStrut(5));
        panel.add(toRegisterBtn);

        loginBtn.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            Client user = authenticateUser(email, password);
            if (user != null) {
                currentUser = user;

                
                mainPanel.add(createDashboardPanel(), "dashboard");

                JOptionPane.showMessageDialog(this, "Login successful!");
                updateDashboard(user);
                cardLayout.show(mainPanel, "dashboard");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        toRegisterBtn.addActionListener(e -> cardLayout.show(mainPanel, "register"));

        return panel;
    }

    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Register", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel idLabel = new JLabel("ID:");
        JTextField idField = new JTextField(15);

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(15);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(15);

        JLabel roleLabel = new JLabel("Role:");
        String[] roles = {"Student", "Faculty", "Staff", "Visitor"};
        JComboBox<String> roleDropdown = new JComboBox<>(roles);

        JButton registerBtn = new JButton("Register");
        JButton toLoginBtn = new JButton("Back to Login");

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        formPanel.add(idLabel);
        formPanel.add(idField);
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(roleLabel);
        formPanel.add(roleDropdown);

        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        toLoginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(formPanel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(registerBtn);
        panel.add(Box.createVerticalStrut(5));
        panel.add(toLoginBtn);

        registerBtn.addActionListener(e -> {
            String idText = idField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            String role = (String) roleDropdown.getSelectedItem();

            if (idText.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int id;
            try {
                id = Integer.parseInt(idText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID must be a number!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (registerUser(id, email, password, role)) {
                JOptionPane.showMessageDialog(this, "Registration successful!");
                cardLayout.show(mainPanel, "login");
            } else {
                JOptionPane.showMessageDialog(this, "Registration failed!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        toLoginBtn.addActionListener(e -> cardLayout.show(mainPanel, "login"));

        return panel;
    }

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    
        JLabel title = new JLabel("Dashboard", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        dashboardLabel = new JLabel("Welcome, User!", SwingConstants.CENTER);
        dashboardLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        JLabel bookingInfoLabel = new JLabel("", SwingConstants.CENTER);
        bookingInfoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
        // ✅ Start a timer to auto-update the booking info label every 30 seconds
        new javax.swing.Timer(30000, e -> updateBookingInfoLabel(bookingInfoLabel)).start();
    
        JButton bookParkingBtn = new JButton("Book Parking");
        bookParkingBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        bookParkingBtn.addActionListener(e -> cardLayout.show(mainPanel, "booking"));
    
        JButton extendBookingBtn = new JButton("Extend Booking");
        extendBookingBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        extendBookingBtn.addActionListener(e -> {
            if (currentUser.getBooking() == null) {
                JOptionPane.showMessageDialog(this, "You don't have a booking to extend.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
    
            String input = JOptionPane.showInputDialog(this, "Enter number of hours to extend:");
            if (input == null || input.isEmpty()) return;
    
            try {
                int hours = Integer.parseInt(input);
                if (hours <= 0) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid number of hours.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
    
                currentUser.getBooking().extendByHours(hours);
                JOptionPane.showMessageDialog(this, "Booking extended by " + hours + " hour(s).");
                updateBookingInfoLabel(bookingInfoLabel);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    
        JButton cancelBookingBtn = new JButton("Cancel Booking");
        cancelBookingBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        cancelBookingBtn.addActionListener(e -> {
            if (currentUser.getBooking() == null) {
                JOptionPane.showMessageDialog(this, "You don't have any booking to cancel.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
    
            try {
                CancelBooking cancelBooking = new CancelBooking(currentUser.getBooking());
                if (cancelBooking.execute()) {
                    ParkingSpace space = currentUser.getBooking().getBookedSpace();
                    space.setState(new VacantState(space));
    
                    // ✅ Reset button color
                    JPanel bookingPanel = (JPanel) mainPanel.getComponent(2);
                    for (Component comp : bookingPanel.getComponents()) {
                        if (comp instanceof JPanel) {
                            for (Component btn : ((JPanel) comp).getComponents()) {
                                if (btn instanceof JButton) {
                                    JButton button = (JButton) btn;
                                    if (button.getText().equals(space.getspace_Location())) {
                                        updateButtonState(space, button);
                                    }
                                }
                            }
                        }
                    }
    
                    currentUser.setBooking(null);
                    JOptionPane.showMessageDialog(this, "Booking cancelled successfully.");
                    updateBookingInfoLabel(bookingInfoLabel);
                } else {
                    JOptionPane.showMessageDialog(this, "Unable to cancel booking.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error cancelling booking.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.addActionListener(e -> {
            currentUser = null;
            cardLayout.show(mainPanel, "login");
        });
    
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(dashboardLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(bookingInfoLabel);
        panel.add(Box.createVerticalStrut(10));
    
        if (!isManager(currentUser.getEmail()) && !"superadmin".equalsIgnoreCase(currentUser.getEmail())) {
            panel.add(bookParkingBtn);
            panel.add(Box.createVerticalStrut(10));
            panel.add(extendBookingBtn);
            panel.add(Box.createVerticalStrut(10));
            panel.add(cancelBookingBtn);
        }
    
        if (isManager(currentUser.getEmail())) {
            JButton managerApprovalBtn = new JButton("Manager Approval");
            managerApprovalBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
            managerApprovalBtn.addActionListener(e -> new ManagerApproval().setVisible(true));
            panel.add(Box.createVerticalStrut(10));
            panel.add(managerApprovalBtn);
        }
    
        if ("superadmin".equalsIgnoreCase(currentUser.getEmail())) {
            JButton superManagerBtn = new JButton("Super Manager Dashboard");
            superManagerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
            superManagerBtn.addActionListener(e -> new SuperManagerDashboard().setVisible(true));
            panel.add(Box.createVerticalStrut(10));
            panel.add(superManagerBtn);
        }
    
        panel.add(Box.createVerticalStrut(10));
        panel.add(logoutBtn);
    
        // Update on load
        updateBookingInfoLabel(bookingInfoLabel);
    
        return panel;
    }
    
    
    private JPanel createBookingPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel title = new JLabel("Parking Booking", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(title, BorderLayout.NORTH);

        ParkingLot parkingLot = new ParkingLot("Main Lot");
        JPanel parkingGrid = new JPanel(new GridLayout(10, 10, 5, 5));
        panel.add(parkingGrid, BorderLayout.CENTER);

        JButton backToDashboard = new JButton("Back to Dashboard");
        panel.add(backToDashboard, BorderLayout.SOUTH);

        for (int i = 1; i <= 100; i++) {
            ParkingSpace space = new ParkingSpace(parkingLot, "Space " + i);
            JButton spaceButton = new JButton(space.getspace_Location());

            updateButtonState(space, spaceButton);
            int bookingId = i;

            spaceButton.addActionListener(e -> {
                if (space.getState() instanceof VacantState) {
                    if (currentUser.getBooking() != null) {
                        JOptionPane.showMessageDialog(this, "You already have a booking!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    try {
                        Booking booking = new Booking();
                        booking.setId(bookingId);
                        Date start = new Date();
                        booking.setStartTime(start);
                        // ✅ Set end time to 1 hour later by default
                        booking.setExitTime(new Date(start.getTime() + 60L * 60 * 1000));

                        booking.setBookedSpace(space);


                        BookParking bookParking = new BookParking(booking, space);
                        bookParking.execute();

                        currentUser.setBooking(booking);
                        space.setState(new OccupiedState(space));
                        updateButtonState(space, spaceButton);
                        JOptionPane.showMessageDialog(this, "Booked " + space.getspace_Location());
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(this, "Booking failed!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "This space is already booked!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            parkingGrid.add(spaceButton);
        }

        backToDashboard.addActionListener(e -> cardLayout.show(mainPanel, "dashboard"));
        backToDashboard.addActionListener(e -> cardLayout.show(mainPanel, "dashboard"));

        return panel;
        }

        private void updateButtonState(ParkingSpace space, JButton button) {
        if (space.getState() instanceof VacantState) {
            button.setBackground(Color.GREEN);
        } else if (space.getState() instanceof OccupiedState) {
            button.setBackground(Color.RED);
        } else if (space.getState() instanceof DisabledState) {
            button.setBackground(Color.GRAY);
        }
        }

        private void updateDashboard(Client user) {
        dashboardLabel.setText("<html>Welcome, " + user.getEmail() + "<br>Role: " + user.getClass().getSimpleName() +
            "<br>Rate: $" + user.getRate() + "/hour</html>");
    }

    private Client authenticateUser(String email, String password) {
        try {
            CsvReader reader = new CsvReader("Deliverable2/user.csv");
            reader.readHeaders();
    
            while (reader.readRecord()) {
                String storedEmail = reader.get("email").trim();
                String storedPassword = reader.get("password").trim();
                String storedRole = reader.get("role").trim();
                String status = reader.get("status").trim();
    
                // ✅ Superadmin check
                if (storedEmail.equals(email) && storedPassword.equals(password)
                    && storedRole.equalsIgnoreCase("SuperManager")
                    && status.equalsIgnoreCase("approved")) {
    
                    System.out.println("✅ Superadmin login detected");
                    return new Client() {
                        public boolean login(String e, String p) { return true; }
                        public boolean logout() { return true; }
                        public String getEmail() { return storedEmail; }
                        public double getRate() { return 0.0; }
                        public Booking getBooking() { return null; }
                        public void setBooking(Booking b) {}
                        public void initiateBooking() {}
                        public void initiatePayment() {}
                        public boolean register(String e, String p, int id) { return false; }
                    };
                }
    
                // ✅ Manager check
                if (storedEmail.equals(email) && storedPassword.equals(password)
                    && storedRole.equalsIgnoreCase("Manager")
                    && status.equalsIgnoreCase("approved")) {
    
                    System.out.println("✅ Manager login detected");
                    return new Client() {
                        public boolean login(String e, String p) { return true; }
                        public boolean logout() { return true; }
                        public String getEmail() { return storedEmail; }
                        public double getRate() { return 0.0; }
                        public Booking getBooking() { return null; }
                        public void setBooking(Booking b) {}
                        public void initiateBooking() {}
                        public void initiatePayment() {}
                        public boolean register(String e, String p, int id) { return false; }
                    };
                }
            }
    
            reader.close();
    
            // ✅ Then check normal users
            Client[] users = {
                new Student(),
                new Faculty(),
                new Staff(),
                new Visitor()
            };
    
            for (Client user : users) {
                if (user.login(email, password)) {
                    return user;
                }
            }
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    
        return null;
    }
    private void updateBookingInfoLabel(JLabel label) {
        if (currentUser != null && currentUser.getBooking() != null) {
            Date now = new Date();
            Date end = currentUser.getBooking().getExitTime();
    
            if (end == null) {
                label.setText("Booking active. End time not set.");
                return;
            }
    
            long diffMillis = end.getTime() - now.getTime();
            if (diffMillis <= 0) {
                label.setText("⚠️ Booking expired.");
            } else {
                long minutes = diffMillis / (1000 * 60);
                long hours = minutes / 60;
                minutes %= 60;
    
                label.setText("Booking ends at: " + end +
                              " | Remaining: " + hours + "h " + minutes + "m");
            }
        } else {
            label.setText("No active booking.");
        }
    }
    


    private boolean registerUser(int id, String email, String password, String role) {
        try {
            Client user;
            switch (role) {
                case "Student":
                    user = new Student();
                    break;
                case "Faculty":
                    user = new Faculty();
                    break;
                case "Staff":
                    user = new Staff();
                    break;
                case "Visitor":
                    user = new Visitor();
                    break;
                default:
                    return false;
            }

            return user.register(email, password, id);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GUI gui = new GUI();
            gui.setVisible(true);
        });
    }
}


